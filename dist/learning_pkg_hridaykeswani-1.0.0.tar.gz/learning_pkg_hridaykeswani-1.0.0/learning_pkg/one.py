def say_hello():
    print("Hello......")

def add_one(num):
    return num+1